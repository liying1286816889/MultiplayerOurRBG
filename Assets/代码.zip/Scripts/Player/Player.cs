 using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Player : Entity
{

    [Header("��ҹ�����Ϣ")]
    public Vector2[] attackMovement;
    [Header("��ҷ���ʱ��")]
    public float counterAttackDuration=0.2f; 

    public bool isBusy { get; private set; }
    [Header("��ҹ�����Ϣ")]
    public float attackSpeed = 1f;//�����ٶ�
    
    [Header("����ƶ���Ϣ")]
    public float moveSpeed = 12f; //�ƶ��ٶ�
    public float jumpForce = 12f; //��Ծ�ٶ�
    public float swordReturnImpact = 4f;
    private float defaultMoveSpeed;
    private float defaultJumpForce;


    [Header("��ҳ����Ϣ")]
    public float dashSpeed;
    public float dashDuration;
    private float defaultDashSpeed;



   

    public float dashDir { get; private set; }

    public bool isBleed;

    public SkillManager skill { get; private set; } //���ܹ�����
    public GameObject sword { get; private set; }
    public PlayerFX fx { get; private set; }


    #region ���״̬
    //���״̬�� 
    public PlayerStateMachine stateMachine { get; private set; }
    //����ƶ�״̬��
    public PlayerMoveState moveState { get; private set; }
    //�������״̬��
    public PlayerIdleState idleState { get; private set; }
    //�����Ծ״̬
    public PlayerJumpState jumpState { get; private set; }
    //����ڿ���״̬
    public PlayerAirState airState { get; private set; }
    //��ҳ��״̬
    public PlayerDashState dashState { get; private set; }
    //�����ǽ״̬
    public PlayerWallSlideState wallSlide { get; private set; }
    //�����ǽ��Ծ״̬
    public PlayerWallJumpState wallJump { get; private set; }
    //��ҹ���״̬
    public PlayerPrimaryAttackState primaryAttack { get; private set; }
    //��ҷ���״̬
    public PlayerCounterAttackState counterAttack { get; private set; }
    //����ý���׼״̬
    public PlayerAimSwordState aimSword { get; private set; }
    //��һ��ս�
    public PlayerCatchSwordState catchSword { get; private set; }
    //����ͷźڶ�
    public PlayerBlackholeState blackHoleState { get; private set; }
    //�������
    public PlayerDeadState deadState { get; private set; }

    #endregion

    //ʵ��������
    protected override void Awake()
    {
        base.Awake();
        this.isEnemy = false;
        stateMachine = new PlayerStateMachine();
        idleState = new PlayerIdleState(stateMachine, this, "Idle");
        moveState = new PlayerMoveState(stateMachine, this, "Move");
        jumpState = new PlayerJumpState(stateMachine, this, "Jump");
        airState  = new PlayerAirState(stateMachine, this, "Jump");
        dashState = new PlayerDashState(stateMachine, this, "Dash");
        wallSlide = new PlayerWallSlideState(stateMachine, this, "WallSlide");
        wallJump  = new PlayerWallJumpState(stateMachine, this, "Jump");
        primaryAttack = new PlayerPrimaryAttackState(stateMachine, this, "Attack");
        counterAttack = new PlayerCounterAttackState(stateMachine, this, "CounterAttack");
        aimSword = new PlayerAimSwordState(stateMachine, this, "AimSword");
        catchSword = new PlayerCatchSwordState(stateMachine, this, "CatchSword");
        blackHoleState = new PlayerBlackholeState(stateMachine, this, "Jump");
        deadState = new PlayerDeadState(stateMachine, this, "Die");
    }
    //��������,��ʼ������
    protected override void Start()
    {
        base.Start();


        stateMachine.Initialize(idleState);
        skill = SkillManager.instance;
        fx = GetComponent<PlayerFX>();

        defaultMoveSpeed = moveSpeed;
        defaultJumpForce = jumpForce;
        defaultDashSpeed = dashSpeed;
    }

    //���º���
    protected override void Update()
    {
        if (Time.timeScale == 0)
        {
            return;
        }

        base.Update();
        stateMachine.currentState.Update();


        CheckForDashInput();

        if (Input.GetKeyDown(KeyCode.F)&&skill.crystal.crystalUnlocked)
        {
            skill.crystal.CanUseSkill();
        }

        if(Input.GetKeyDown(KeyCode.Alpha1))
        {
            Inventory.instance.UseFlask();
        }

    }

    public override void SlowEntityBy(float _slowPercentage, float _slowDuration)
    {
        moveSpeed = moveSpeed * (1 - _slowPercentage);
        jumpForce = jumpForce * (1 - _slowPercentage);
        dashSpeed = dashSpeed * (1 - _slowPercentage);
        anim.speed = anim.speed * (1 - _slowPercentage);

        Invoke("ReturnDefaultSpeed", _slowDuration);
    }

    protected override void ReturnDefaultSpeed()
    {
        base.ReturnDefaultSpeed();
        moveSpeed = defaultMoveSpeed;
        jumpForce = defaultJumpForce;
        dashSpeed = defaultDashSpeed;

    }


    public void AssignNewSword(GameObject _newSword)
    {
        sword = _newSword;

    }
    public void CatchTheSword()
    {
        stateMachine.ChangeState(catchSword);
        Destroy(sword);
    }

       

    public IEnumerator BusyFor(float _seconds)
    {
        isBusy = true;
        yield return new WaitForSeconds(_seconds);
        isBusy = false;
    }


    public void AnimationTrigger()=>stateMachine.currentState.AnimationFinishTrigger();


    //�����û�н�����״̬
    private void CheckForDashInput()
    {
        if (IsWallDetected()&&!IsGroundDetected())
            return;

        if(skill.dash.dashUnlocked==false)return;


        if (Input.GetKeyDown(KeyCode.LeftShift)&&SkillManager.instance.dash.CanUseSkill())
        {
            dashDir =Input.GetAxisRaw("Horizontal");

            if (dashDir == 0)
                dashDir = facingDir;

            stateMachine.ChangeState(dashState);
        }

    }
    public override void Die()
    {
        base.Die();
        stateMachine.ChangeState(deadState);
    }

    protected override void SetupZeroKnockbackPower()
    {
        knockbackPower = new Vector2(0, 0);

    }

}
