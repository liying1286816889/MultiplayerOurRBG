using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStateMachine //: MonoBehaviour
{
    public PlayerState currentState { get; private set; }
    //��ʼ������
    public void Initialize(PlayerState _starState)
    {
        currentState = _starState;
        currentState.Enter();
    }
    //�ı�״̬�ĺ���
    public void ChangeState(PlayerState _newState)
    {
        currentState.Exit();
        currentState = _newState;
        currentState.Enter();
    }



}
