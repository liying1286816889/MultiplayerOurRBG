using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerState //: MonoBehaviour
{
    protected PlayerStateMachine stateMachine;
    protected Player player;
    protected Rigidbody2D rb;


    //x����ƫ����
    protected float xInput;
    //y����ƫ����
    protected float yInput;

    //��������
    private string animBoolName;
    protected float stateTimer;
    protected bool triggerCalled;


    public PlayerState(PlayerStateMachine _stateMachine, Player _player, string animBoolName)
    {
        this.stateMachine = _stateMachine;
        this.player = _player;
        this.animBoolName = animBoolName;
    }
    //״̬����
    public virtual void Enter()
    {
        player.anim.SetBool(animBoolName, true);
        rb=player.rb;
        triggerCalled = false;
    }
    //���º���
    public virtual void Update()
    {
        stateTimer -= Time.deltaTime;
        xInput = Input.GetAxisRaw("Horizontal");
        yInput=Input.GetAxisRaw("Vertical");
        player.anim.SetFloat("yVelocity", rb.velocity.y);
    }

    //�˳�����
    public virtual void Exit()
    {
        player.anim.SetBool(animBoolName, false);

    }

    public virtual void AnimationFinishTrigger()
    {
        triggerCalled = true;
    }


}
