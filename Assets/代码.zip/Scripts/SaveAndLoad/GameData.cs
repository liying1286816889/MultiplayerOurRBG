using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GameData 
{
    public int currency;

    public SerializableDictionary<string, bool> skillTree;

    public SerializableDictionary<string, int> inventory;

    public List<string> equipmentId;

    public SerializableDictionary<string, bool> checkpoints;

    public string closestCheckpointId;

    public int lostCurrencyAmount;

    public float lostCurrencyX;
    
    public float lostCurrencyY;

    public SerializableDictionary<string, float> voluemSettings;

    public GameData()
    {
        this.lostCurrencyX = 0;
        this.lostCurrencyY = 0;
        this.lostCurrencyAmount = 0;

        this.currency = 0;
        skillTree = new SerializableDictionary<string, bool>();
        this.inventory=new SerializableDictionary<string, int>();
        equipmentId = new List<string>();

        closestCheckpointId = string.Empty;
        checkpoints =new SerializableDictionary<string, bool>();

        voluemSettings = new SerializableDictionary<string, float>();
        
    }


}
