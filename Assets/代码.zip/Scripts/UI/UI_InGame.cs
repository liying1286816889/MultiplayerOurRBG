using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_InGame : MonoBehaviour
{
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private Slider slider;
    [SerializeField] private Image dashImage;
    [SerializeField] private Image parryImage;
    [SerializeField] private Image crystalImage;
    [SerializeField] private Image swordImage;
    [SerializeField] private Image blackholeImage;
    [SerializeField] private Image flaskImage;


    [Header("Solus info")]
    [SerializeField] private TextMeshProUGUI currentSouls;
    [SerializeField] private float soulsAmount;
    [SerializeField] private float increaseRate = 100;

    private SkillManager skills;

    private void Start()
    {
        if (playerStats != null)
        {
            playerStats.onHealthChanged += UpdateHealthUI;
        }
        skills=SkillManager.instance;



    }
    private void Update()
    {
        UpdataSoulsUI();

        if (Input.GetKeyUp(KeyCode.LeftShift) && skills.dash.dashUnlocked)
        {
            SetCooldownOf(dashImage);
        }

        if (Input.GetKeyUp(KeyCode.Q) && skills.parry.parryUnLocked)
        {
            SetCooldownOf(parryImage);
        }

        if (Input.GetKeyUp(KeyCode.F) && skills.crystal.crystalUnlocked)
        {
            SetCooldownOf(crystalImage);
        }

        if (Input.GetKeyUp(KeyCode.Mouse1) && skills.sword.swordUnlocked)
        {
            SetCooldownOf(swordImage);
        }

        if (Input.GetKeyUp(KeyCode.R) && skills.blackhole.blackHoleUnlocked)
        {
            SetCooldownOf(blackholeImage);
        }

        if (Input.GetKeyUp(KeyCode.Alpha1) && Inventory.instance.GetEquipment(EquipmentType.Flask) != null)
        {
            SetCooldownOf(flaskImage);
        }

        //���ͼ�� 
        CheckCooldownOf(dashImage, skills.dash.cooldown);
        //����ͼ��
        CheckCooldownOf(parryImage, skills.parry.cooldown);
        //ˮ��ͼ��
        CheckCooldownOf(crystalImage, skills.crystal.cooldown);
        //��ͼ��
        CheckCooldownOf(swordImage, skills.sword.cooldown);
        //�ڶ�ͼ��
        CheckCooldownOf(blackholeImage, skills.blackhole.cooldown);
        //ҩˮͼ��
        CheckCooldownOf(flaskImage, Inventory.instance.flaskCooldown);
    }

    private void UpdataSoulsUI()
    {
        if (soulsAmount < PlayerManager.instance.GetCurrency())
        {
            soulsAmount += Time.deltaTime * increaseRate;
        }
        else
        {
            soulsAmount = PlayerManager.instance.GetCurrency();
        }

        currentSouls.text = Mathf.RoundToInt(soulsAmount).ToString();
    }

    private void UpdateHealthUI()
    {
        slider.maxValue = playerStats.GetMaxHealthValue();
        slider.value = playerStats.currentHealth;
    }

    private void SetCooldownOf(Image _image)
    {
        if (_image.fillAmount <= 0)
        {
            _image.fillAmount = 1;
        }
        
    }

    private void CheckCooldownOf(Image _image,float _cooldown)
    {
        if (_cooldown == 0) return; 
        if (_image.fillAmount > 0)
        {
            _image.fillAmount -= 1/_cooldown*Time.deltaTime;
        }

    }

}
