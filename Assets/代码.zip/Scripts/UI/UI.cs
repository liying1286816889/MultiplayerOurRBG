using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UI : MonoBehaviour,ISaveManager
{

    [Header("������Ļ")]
    [SerializeField] public UI_FadeScreen fadeScreen;
    [SerializeField] private GameObject endText;
    [SerializeField] private GameObject restartButton;


    [SerializeField] private GameObject characterUI;
    [SerializeField] private GameObject skillTreeUI;
    [SerializeField] private GameObject craftUI;
    [SerializeField] private GameObject optionsUI;
    [SerializeField] private GameObject inGameUI;

    

    public UI_ItemToolTip itemToolTip;
    public UI_StatsToolTip statsToolTip;
    public UI_CraftWindow craftWindow;
    public UI_SkillToolTip skillToolTip;
    public bool ischange=false;

    [SerializeField] private UI_VolumeSlider[] volumeSettings;

    int currentMenuIndex = 0;

    private void Awake()
    {

        SwitchTo(skillTreeUI);//�ȼ��ؼ�������ʹ����Ա�SkillManager����
        fadeScreen.gameObject.SetActive(true); 

    }



    void Start()
    {
        SwitchTo(null);
        SwitchTo(inGameUI);
        itemToolTip.gameObject.SetActive(false);
        statsToolTip.gameObject.SetActive(false);

        foreach (UI_VolumeSlider item in volumeSettings)
        {
            item.SliderValue(item.slider.value);

        }

    }

    void Update()
    {
        SwitchMenu();
    }

    


    private void SwitchMenu()
    {
        if(characterUI.activeInHierarchy)
        {
            currentMenuIndex = 1;
        }else if ( skillTreeUI.activeInHierarchy)
        {
            currentMenuIndex = 2;
        }else if( craftUI.activeInHierarchy)
        {
            currentMenuIndex = 3;
        }
        else if ( optionsUI.activeInHierarchy)
        {
            currentMenuIndex = 4;
        }
        else
        {
            currentMenuIndex = 0;
            
        }

        if (Input.GetKeyDown(KeyCode.B) || Input.GetKeyDown(KeyCode.Tab))
        {
            AudioManager.instance.PlaySFX(7);
            currentMenuIndex = 1;
        }

        if (currentMenuIndex != 0)
        {
            if (characterUI.activeInHierarchy || skillTreeUI.activeInHierarchy || craftUI.activeInHierarchy || optionsUI.activeInHierarchy)
            {
                if (Input.GetKeyDown(KeyCode.B) || Input.GetKeyDown(KeyCode.Tab) || Input.GetKeyDown(KeyCode.Escape))
                {
                    AudioManager.instance.PlaySFX(7);
                    currentMenuIndex = 0;
                    ischange = true;
                }
            }


            if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.E))
            {
                AudioManager.instance.PlaySFX(7);
                currentMenuIndex++;
                if (currentMenuIndex > 4)
                {
                    currentMenuIndex = 1;
                }

            }

            if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.Q))
            {
                AudioManager.instance.PlaySFX(7);
                currentMenuIndex--;
                if (currentMenuIndex < 1)
                {
                    currentMenuIndex = 4;
                }
            }
        }

        if (!ischange && currentMenuIndex == 0)
        {
            return;
        }

        ischange = false;

        //��̬�¿�������InGameUI
        if (currentMenuIndex == 0)
        {
            SwitchWithKeyTo(null);
            CheckForInGameUI();
        }
        else if (currentMenuIndex == 1)
        {
            SwitchWithKeyTo(characterUI);
        }
        else if (currentMenuIndex == 2)
        {
            SwitchWithKeyTo(skillTreeUI);
        }
        else if (currentMenuIndex == 3)
        {
            SwitchWithKeyTo(craftUI);
        }
        else if (currentMenuIndex == 4)
        {
            SwitchWithKeyTo(optionsUI);
        }

    }



    public void SwitchTo(GameObject _menu)
    {


        for (int i = 0; i < transform.childCount; i++)
        {
            bool FadeScreen = transform.GetChild(i).GetComponent<UI_FadeScreen>() != null;//������Ҫһֱ���ּ���״̬
            if (FadeScreen == false)
            {
                transform.GetChild(i).gameObject.SetActive(false);
            }
        }

        if(_menu!=null)
        {

            _menu.SetActive(true);
        }

        if (GameManager.instance!=null)
        {
            if (_menu == inGameUI)
            {
                GameManager.instance.PauseGame(false);
            }
            else
            {
                GameManager.instance.PauseGame(true);
            }

        }



    }

    public void SwitchWithKeyTo(GameObject _menu) 
    {
        if(_menu!=null&&_menu.activeSelf)
        {
            _menu.SetActive(false);
            
        }

        SwitchTo(_menu);
    }

    private void CheckForInGameUI()
    {
        //FadeScene��һֱ���ڼ���״̬�����Ե���������״̬�������������
        for (int i = 0; i < transform.childCount; i++)
        {
            if (transform.GetChild(i).gameObject.activeSelf && transform.GetChild(i).GetComponent<UI_FadeScreen>()==null)
            {

                return;
            }
        }
        SwitchTo(inGameUI);
    }

    public void SwitchOnEndScreen()
    {

        fadeScreen.FadeOut();
        StartCoroutine(EndScreenCorutione());
    }

    IEnumerator EndScreenCorutione()
    {
        yield return new WaitForSeconds(1f);
        endText.SetActive(true);
        yield return new WaitForSeconds(1.5f);
        restartButton.SetActive(true);

    }

    public void ReStartButton()
    {
        GameManager.instance.RestartScene();
    }

    


    public void LoadData(GameData _data)
    {
        foreach (KeyValuePair<string,float> pair in _data.voluemSettings)
        {
            foreach (UI_VolumeSlider item in volumeSettings)
            {
                if (item.parameter == pair.Key)
                {
                    item.LoadSlider(pair.Value);
                }
                
            }

        }
    }


    public void SaveData(ref GameData _data)
    {
        _data.voluemSettings.Clear();

        foreach (UI_VolumeSlider item in volumeSettings)
        {
            _data.voluemSettings.Add(item.parameter, item.slider.value);
        }

    }

}
