using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemObject : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] public ItemData itemData;


    


    private void SetUpVisuals()
    {
        if (itemData == null) return;

        GetComponent<SpriteRenderer>().sprite = itemData.icon;
        gameObject.name = "ItemObject_" + itemData.itemName;
    }

    private void Update()
    {

    }

    public void SteUpItem(ItemData _itemData,Vector2 _velocity)
    {

        itemData = _itemData;
        rb.velocity = _velocity;

        SetUpVisuals();
    }



    public void PickUpItem()
    {
        if (!Inventory.instance.CanAddItem() && itemData.ItemType == ItemType.Equipment)
        {
            rb.velocity = new Vector2(0, 7);
            PlayerManager.instance.player.fx.CreatePopUpText("û�ж���ռ�");
            return;
        }

        AudioManager.instance.PlaySFX(18,transform);
        Inventory.instance.AddItem(itemData);
        Destroy(gameObject);
    }
}
