using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour,ISaveManager
{
    public static GameManager instance;
    

    private Transform player;

    [SerializeField] CheckPiont[] checkpoins;

    [SerializeField] private string closestCheckPointId;

    [Header("Lost currency")]
    [SerializeField] private GameObject lostCurrencyPrefab;
    public int lostCurrencyAmount;
    private float lostCurrencyX;
    private float lostCurrencyY;


    public void RestartScene()
    {
        SaveManager.instance.SaveGame();
        Scene scene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(scene.name);
    }


    private void Start()
    {


    }

    public void Awake()
    {
        player = PlayerManager.instance.player.transform;
        if (instance != null)
        {
            Destroy(instance.gameObject);
        }
        else
        {
            instance = this;
        }

    }

    public void LoadData(GameData _data)
    {
        StartCoroutine(LoadWithDelay(_data));
    }


    private IEnumerator LoadWithDelay(GameData _data)
    {
        yield return new WaitForSeconds(.1f);
        LoadCheckpoints(_data);
        LoadClosestCheckpoint(_data);

        LoadLostCurrency(_data);


    }
    private void LoadCheckpoints(GameData _data)
    {
        checkpoins = FindObjectsOfType<CheckPiont>();
        foreach (KeyValuePair<string, bool> pair in _data.checkpoints)
        {
            foreach (CheckPiont checkpoint in checkpoins)
            {
                if (checkpoint.id == pair.Key && pair.Value == true)
                {
                    checkpoint.ActivateCheckPoint();
                }
            }
        }
    }
    private void LoadClosestCheckpoint(GameData _data)
    {
        if (closestCheckPointId == null)
            return;

        closestCheckPointId = _data.closestCheckpointId;

        foreach (CheckPiont checkPiont in checkpoins)
        {
            if (closestCheckPointId == checkPiont.id)
            {
                player.position = checkPiont.transform.position;

            }
        }
    }

    private void LoadLostCurrency(GameData _data)
    {
        lostCurrencyAmount = _data.lostCurrencyAmount;
        lostCurrencyX = _data.lostCurrencyX;
        lostCurrencyY = _data.lostCurrencyY;

        if (lostCurrencyAmount > 0)
        {
            GameObject newLostCurrency = Instantiate(lostCurrencyPrefab, new Vector3(lostCurrencyX, lostCurrencyY, 0),Quaternion.identity);
            newLostCurrency.GetComponent<LostCurrentcyController>().currentcy=lostCurrencyAmount;

        }
        lostCurrencyAmount = 0;
    }

    

    public void SaveData(ref GameData _data)
    {

        _data.lostCurrencyAmount = lostCurrencyAmount;
        _data.lostCurrencyX = player.position.x;
        _data.lostCurrencyY = player.position.y;

        if (FindClosestCheckPoint() != null)
        {
            _data.closestCheckpointId = FindClosestCheckPoint().id;
        }

        _data.checkpoints.Clear();

        foreach (CheckPiont checkpiont in checkpoins) 
        {
            _data.checkpoints.Add(checkpiont.id, checkpiont.activationStatus);
        }

    }

    
    private CheckPiont FindClosestCheckPoint()
    {
        float closestDistance=Mathf.Infinity;
        CheckPiont closestCheckPoint = null;
        foreach (var checkPiont in checkpoins)
        {
            float distanceToCheckPoint = Vector2.Distance(player.position, checkPiont.transform.position);
            if(distanceToCheckPoint < closestDistance&&checkPiont.activationStatus==true)
            {
                closestDistance = distanceToCheckPoint;
                closestCheckPoint=checkPiont;
            }
        }

        return closestCheckPoint;
    }

    public void PauseGame(bool _pause)
    {
        if (_pause)
        {
            Time.timeScale = 0;
        }
        else
        {
            Time.timeScale = 1;
        }

    }


}
