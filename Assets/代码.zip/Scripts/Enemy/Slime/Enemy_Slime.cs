using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public enum SlimeType
{
    big_slime,
    medium_slime,
    small_slime
}



public class Enemy_Slime : Enemy
{
    [Header("����ʷ��ķ")]
    [SerializeField] private SlimeType slimeType;
    [SerializeField] private int slimesToCreate;
    [SerializeField] private GameObject slimePrefab;
    [SerializeField] private Vector2 minCreationVelocity;
    [SerializeField] private Vector2 maxCreationVelocity;


    #region ʷ��ķ״̬
    public SlimeIdleState idleState { get; private set; }
    public SlimeMoveState moveState { get; private set; }
    public SlimeBattleState battleState { get; private set; }
    public SlimeAttackState attackState { get; private set; }
    public SlimeStunnedState stunnedState { get; private set; }
    public SlimeDeadState deadState { get; private set; }
    #endregion

    protected override void Awake()
    {
        base.Awake();

        idleState = new SlimeIdleState(this, stateMachine, "Idle", this);
        moveState = new SlimeMoveState(this, stateMachine, "Move", this);
        battleState = new SlimeBattleState(this, stateMachine, "Move", this);
        attackState = new SlimeAttackState(this, stateMachine, "Attack", this);
        stunnedState = new SlimeStunnedState(this, stateMachine, "Stunned", this);
        deadState = new SlimeDeadState(this, stateMachine, "Idle", this);
    }

    protected override void Start()
    {
        base.Start();
        SetupDefailtFacingDir(-1);
        stateMachine.Initialize(idleState);
    }

    
    public override bool CanBeStunned()
    {
        if (base.CanBeStunned())
        {
            stateMachine.ChangeState(stunnedState);
            return true;
        }
        return false;
    }
    public override void Die()
    {
        base.Die();
        stateMachine.ChangeState(deadState);
        if (slimeType == SlimeType.small_slime)
        {
            return;
        }
        CreateSlimes(slimesToCreate, slimePrefab);

    }

    public override void Flip()
    {
        base.Flip();

        switch(this.slimeType)
        {
            case SlimeType.big_slime:
                transform.position =new Vector3(transform.position.x+7*facingDir, transform.position.y, transform.position.z);
                break;
            case SlimeType.medium_slime:
                transform.position =new Vector3(transform.position.x+5*facingDir, transform.position.y, transform.position.z);
                break;
            case SlimeType.small_slime:
                transform.position =new Vector3(transform.position.x+3*facingDir, transform.position.y, transform.position.z);
                break;
        }
    }

    public void CreateSlimes(int _amountOfSlime,GameObject _slimePrefab)
    {
        for (int i = 0; i < _amountOfSlime; i++)
        {
            GameObject newSlime = Instantiate(_slimePrefab, transform.position,Quaternion.identity);
        }

    }

    public void SetupSlime(int _facingDir)
    {
        if(_facingDir!=facingDir)
        {
            Flip();
        }

        float xVelocity=Random.Range(minCreationVelocity.x, maxCreationVelocity.x);
        float yVelocity=Random.Range(minCreationVelocity.y, maxCreationVelocity.y); 

        isKnocked = true;
        GetComponent<Rigidbody2D>().velocity = new Vector2(xVelocity * facingDir, yVelocity);

        Invoke("CancelKnockback", 1.5f);

    }

    public void CancelKnockback() =>isKnocked = false;

}
