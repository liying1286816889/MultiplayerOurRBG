using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
using TMPro;

public class EntityFX : MonoBehaviour
{
    protected Player player;
    [SerializeField] Entity entity;
    protected SpriteRenderer sr;
    [Header("�����ı�")]
    [SerializeField] private GameObject popUpTextPrefab;



    [Header("�ܻ�����")]
    [SerializeField] private float flashDuration = 0.2f;
    [SerializeField] private Material hitMat;
    private Material originalMat;

    [Header("Ԫ����ɫ")]

    [SerializeField] private Color[] igniteColor;
    [SerializeField] private Color[] chillColor;
    [SerializeField] private Color[] shockColor;
    [SerializeField] private Color[] bleedColor;

    [Header("Ԫ�ؿ���")]
    [SerializeField] private ParticleSystem  igniteFX;
    [SerializeField] private ParticleSystem  chileFX;
    [SerializeField] private ParticleSystem  shockFX;

    [Header("�����Ч")]
    [SerializeField] private GameObject normalHitFX;
    [SerializeField] private GameObject criticalHitFX;

    private GameObject myHealthBar;


    


    protected virtual void Start()
    {
        sr=GetComponentInChildren<SpriteRenderer>(); 
        originalMat = sr.material;
        player = PlayerManager.instance.player;

        myHealthBar=GetComponentInChildren<UI_HealthBar>().gameObject;
    }
    

    
    public void CreatePopUpText(string _text)
    {
        float randomX = Random.Range(-2, 2);
        float randomY = Random.Range(3, 5);
        Vector3 positionOffset = new Vector3(randomX, randomY, 0);
        GameObject newText = Instantiate(popUpTextPrefab, transform.position+positionOffset, Quaternion.identity);
        newText.GetComponent<TextMeshPro>().text = _text;
        

    }

    


    



    public void MakerTransprent(bool _transprent)
    {
        if (_transprent)
        {
            sr.color = Color.clear;
            myHealthBar.SetActive(false);
        }
        else
        {
            sr.color = Color.white;
            myHealthBar.SetActive(true);
        }
    }

    protected IEnumerator FlashFX()
    {
        sr.material = hitMat;
        Color currentColor=sr.color;
        sr.color = Color.white;
        yield return new WaitForSeconds(flashDuration);
        sr.color = currentColor;
        sr.material = originalMat;
    }

    private void ReadColorBlink()
    {
        if(sr.color!=Color.white)
        {
            sr.color = Color.white;
        }
        else
        {
            sr.color = Color.yellow;
        }

    }

    private void CancelColorChange()
    {
        CancelInvoke();
        sr.color = Color.white;


        igniteFX.Stop();
        chileFX.Stop();
        shockFX.Stop(); 
    }


    //������Ч
    public void IgniteFxUse(float _seconds)
    {
        igniteFX.Play();

        InvokeRepeating("IgnitedColorFX", 0, 0.3f);
        Invoke("CancelColorChange", _seconds);
    }

   //������Ч
    public void ChillFxUse(float _seconds)
    {
        chileFX.Play();

        InvokeRepeating("ChilledColorFX", 0, 0.3f);
        Invoke("CancelColorChange", _seconds);
    }
    //ѣ����Ч
    public void ShockFxUse(float _seconds)
    {
        shockFX.Play();

        InvokeRepeating("ShockedColorFX", 0, 0.3f);
        Invoke("CancelColorChange", _seconds);
    }
    //������Ѫ��Ч
    public void BleedFxUse(float _seconds)
    {
        InvokeRepeating("BleedColorFX", 0, 0.3f);
        Invoke("CancelColorChange", _seconds);
    }

    public void ClearFX()
    {
        sr.color = Color.clear;
    }

    private void IgnitedColorFX() 
    {
        if(sr.color != igniteColor[0])
        {
            sr.color = igniteColor[0];
        }
        else
        {
            sr.color = igniteColor[1];
        }
    }

    



    private void ChilledColorFX()
    {
        if (sr.color != chillColor[0])
        {
            sr.color = chillColor[0];
        }
        else
        {
            sr.color = chillColor[1];
        }
    }

    private void ShockedColorFX()
    {
        if (sr.color != shockColor[0])
        {
            sr.color = shockColor[0];
        }
        else
        {
            sr.color = shockColor[1];
        }
    }


    private void BleedColorFX()
    {
        if (sr.color != bleedColor[0])
        {
            sr.color = bleedColor[0];
        }
        else
        {
            sr.color = bleedColor[1];
        }
    }

    public void CreateHitFX(Transform _target,bool _critical)
    {

        float xPosition = Random.Range(-.5f, .5f);
        float yPosition = Random.Range(-.5f, .5f);
        float zRotation = Random.Range(-90, 90);

        Vector3 hitFXRotaion = new Vector3(0, 0, zRotation);

        GameObject hitPrefab = normalHitFX;

        if (_critical)
        {
            hitPrefab = criticalHitFX;
            float yRotation = 0;
            zRotation = Random.Range(-45, 45);
            //���������ܶ�̬����
            if (entity.facingDir == -1)
            {
                yRotation = 180;
            }

            hitFXRotaion=new(0,yRotation,zRotation);
        }
        GameObject newHitFX = Instantiate(hitPrefab, _target.position + new Vector3(xPosition, yPosition, 0), Quaternion.identity,_target);

        newHitFX.transform.Rotate(hitFXRotaion);
        

        Destroy(newHitFX,.5f);

    }
    


}
