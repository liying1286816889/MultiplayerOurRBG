using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : CharacterStats
{
    private Player player;

    protected override void Start()
    {
        base.Start();
        player = GetComponent<Player>();
    }
    public override void TakeDamage(int _damage)
    {
        base.TakeDamage(_damage);
        player.DamageImpact();
    }
    protected override void Die()
    {
        base.Die();
        player.Die();

        GameManager.instance.lostCurrencyAmount = PlayerManager.instance.currency;
        PlayerManager.instance.currency = 0;


        GetComponent<PlayerItemDrop>()?.GenerateDrop();
    }
    protected override void DecreaseHealthBy(int _damage)
    {
        base.DecreaseHealthBy(_damage);

        if (_damage > GetMaxHealthValue() * .3f)
        {
            player.SetupKnockbackPower(new Vector2(10,6));
            player.fx.ScreenShake(player.fx.shakeHighDamage);
            int randomIndex = Random.Range(34, 36);
            AudioManager.instance.PlaySFX(randomIndex);
            player.isBleed = true;
            if (PlayerManager.instance.player.isBleed)
            {
                PlayerManager.instance.player.fx.ClearFX();
                PlayerManager.instance.player.fx.BleedFxUse(1f);
            }
            PlayerManager.instance.player.isBleed = false;
        }


        ItemData_Equipment currentArmor = Inventory.instance.GetEquipment(EquipmentType.Armor);
        if(currentArmor!=null)
        {
            currentArmor.Effect(player.transform);
        }

    }

    public override void OnEvasion()
    {
        base.OnEvasion();

        player.skill.dodge.CreateMirageOnDodge();
    }

    public void CloneDoDamage(CharacterStats _targetStats,float _multipler)
    {
        if (TargetCanAvoidAttack(_targetStats))
        {
            return;
        }
        int totalDamage = damage.GetValue() + strengths.GetValue();
        if (_multipler > 0) 
        {
            totalDamage= Mathf.RoundToInt(totalDamage*_multipler);
        }


        if (CanCrit())
        {
            totalDamage = CalculateCriticalDamage(totalDamage);
        }

        totalDamage = CheckTargeArmor(_targetStats, totalDamage);
        _targetStats.TakeDamage(totalDamage);

        //���������������ħ���˺�
        DoMagicalDamage(_targetStats);
    }


}
